import heapq
import logging
import os
import time
from itertools import combinations

# Create a directory for logs
log_directory = "logs"
if not os.path.exists(log_directory):
    os.makedirs(log_directory)

# Set up logging configuration to log to a file
logging.basicConfig(
    filename=os.path.join(log_directory, 'astar_debug_logs.txt'),
    filemode='w',
    level=logging.INFO,
    format='%(message)s'
)

class Node(object):
    def __init__(self, x, y, reachable):
        self.reachable = reachable
        self.x = x
        self.y = y
        self.parent = None
        self.g = 0
        self.h = 0
        self.f = 0
        self.adjacent = []  

    def __lt__(self, other):
        return self.f < other.f
    
    def __repr__(self):
        return f"Node(x={self.x}, y={self.y}, reachable={self.reachable}, g={self.g}, h={self.h}, f={self.f})"

class AStar(object):
    MOVE_COST = 1

    def __init__(self):
        self.opened = []
        heapq.heapify(self.opened)
        self.closed = set()
        self.nodes = []
        self.num_obstacles_to_remove = 0
        self.obstacles = []
        self.nodes_expanded = 0
        self.total_obstacles = 0
        self.grid_width = 0
        self.grid_height = 0

    def init_grid(self, input_file):
        logging.info(f"Initializing grid from file: {input_file}")
        with open(input_file, 'r') as file:
            self.grid_width, self.grid_height = map(int, file.readline().strip().split())
            for line in file:
                if "Obstacle to remove" in line:
                    self.num_obstacles_to_remove = int(line.split('=')[-1].strip())
                else:
                    x, y = map(int, line.strip().split())
                    self.obstacles.append((x, y))

            self.total_obstacles = len(self.obstacles)

            # Convert the grid to graph representation
            self.create_graph()

            self.start = self.get_node(0, 0)
            self.end = self.get_node(self.grid_width - 1, self.grid_height - 1)
            
            self.start.g = 0
            self.start.h = self.get_heuristic(self.start)
            self.start.f = self.start.g + self.start.h
            logging.info(f"Grid initialized: {self.grid_width}x{self.grid_height} with obstacles at {self.obstacles}\n")

    def create_graph(self):
        """Convert the grid into a graph representation by establishing edges between reachable nodes."""
        for x in range(self.grid_width):
            for y in range(self.grid_height):
                reachable = (x, y) not in self.obstacles
                node = Node(x, y, reachable)
                self.nodes.append(node)

        # Establish connections (edges) between nodes
        for node in self.nodes:
            adj_nodes = self.get_adjacent_nodes(node)
            for adj in adj_nodes:
                if adj.reachable:  # Ensure the adjacent node is reachable
                    node.adjacent.append(adj)  # Add the edge to the adjacent nodes
    
        logging.info(f"Space complexity - Total nodes created: {len(self.nodes)}")  # Log the number of nodes created

    def reset_pathfinding(self):
        self.opened.clear()
        self.closed.clear()
        self.nodes_expanded = 0
        for node in self.nodes:
            node.g = 0
            node.h = 0
            node.f = 0
            node.parent = None

        self.start.g = 0
        self.start.h = self.get_heuristic(self.start)
        self.start.f = self.start.g + self.start.h

    def get_heuristic(self, node):
        return abs(node.x - self.end.x) + abs(node.y - self.end.y)

    def get_node(self, x, y):
        return self.nodes[x * self.grid_height + y]

    def get_adjacent_nodes(self, node):
        nodes = []
        if node.x < self.grid_width - 1:  
            nodes.append(self.get_node(node.x + 1, node.y))
        if node.y > 0: 
            nodes.append(self.get_node(node.x, node.y - 1))
        if node.x > 0:  
            nodes.append(self.get_node(node.x - 1, node.y))
        if node.y < self.grid_height - 1:  
            nodes.append(self.get_node(node.x, node.y + 1))
        return nodes

    def get_path(self):
        node = self.end
        path = [(node.x, node.y)]
        while node.parent is not None:
            node = node.parent
            path.append((node.x, node.y))
        path.reverse()
        return path

    def update_node(self, adj, node):
        adj.g = node.g + self.MOVE_COST
        adj.h = self.get_heuristic(adj)
        adj.parent = node
        adj.f = adj.g + adj.h
        logging.info(f"Updated node {adj}: g={adj.g}, h={adj.h}, f={adj.f}")

    def evaluate_obstacle_removal(self, obstacle):
        """Evaluate the impact of removing an obstacle."""
        # Temporarily remove the obstacle
        self.obstacles.remove(obstacle)
        self.total_obstacles -= 1

        # Update the reachability of the current obstacle being evaluated
        for node in self.nodes:
            if (node.x, node.y) == obstacle:
                node.reachable = True  # Make the current obstacle reachable

        self.reset_pathfinding()  # Reset the pathfinding state
        
        # Calculate the new path
        new_path = self.run()  
        new_path_length = len(new_path) if new_path is not None else float('inf')

        # Log the path length and obstacle being evaluated
        logging.info(f"Evaluated removing obstacle at {obstacle}: New path length is {new_path_length-1}")

        # Restore the obstacle and make it unreachable again
        self.obstacles.append(obstacle)
        self.total_obstacles += 1
        
        # Restore reachability of the evaluated obstacle
        for node in self.nodes:
            if (node.x, node.y) == obstacle:
                node.reachable = False  # Set back to unreachable

        return new_path_length

    def find_best_single_obstacle_to_remove(self):
        """Find the best single obstacle to remove based on potential path improvement."""
        best_obstacle = None
        best_path_length = float('inf')

        # Calculate the current path length before removing any obstacles
        current_path = self.run()
        self.current_path_length = len(current_path) if current_path is not None else float('inf')

        # Create a temporary list of obstacles to evaluate
        temp_obstacles = self.obstacles.copy()

        for obstacle in temp_obstacles:
            new_length = self.evaluate_obstacle_removal(obstacle)

            # Only consider if the new path length is shorter than the current path length
            if new_length < best_path_length:
                best_path_length = new_length
                best_obstacle = obstacle

        return best_obstacle

    def find_best_multiple_obstacles_to_remove(self):
        """Find the best combination of multiple obstacles to remove based on potential path improvement."""
        best_obstacles = []
        best_path_length = float('inf')

        # Calculate the current path length before removing any obstacles
        current_path = self.run()
        self.current_path_length = len(current_path) if current_path is not None else float('inf')

        # Create a temporary list of obstacles to evaluate
        temp_obstacles = self.obstacles.copy()

        # Generate combinations of obstacles to evaluate
        for num_obstacles in range(1, self.num_obstacles_to_remove + 1):
            for obstacle_combination in combinations(temp_obstacles, num_obstacles):

                # Temporarily remove the selected obstacles
                for obstacle in obstacle_combination:
                    self.obstacles.remove(obstacle)

                # Update the reachability of the removed obstacles
                for node in self.nodes:
                    if (node.x, node.y) in obstacle_combination:
                        node.reachable = True  # Make the removed obstacles reachable

                self.reset_pathfinding()  # Reset the pathfinding state

                # Calculate the new path length
                new_path = self.run()  
                new_path_length = len(new_path) if new_path is not None else float('inf')

               
                # Restore the removed obstacles and their reachability
                for obstacle in obstacle_combination:
                    self.obstacles.append(obstacle)

                for node in self.nodes:
                    if (node.x, node.y) in obstacle_combination:
                        node.reachable = False  # Restore reachability of the obstacles

                # Check if this combination of obstacles resulted in a better path
                if new_path_length < best_path_length:
                    best_path_length = new_path_length
                    best_obstacles = obstacle_combination

        return best_obstacles

    def run(self):
        start_time = time.time()
        heapq.heappush(self.opened, (self.start.f, self.start))
        logging.info(f"Initial opened list: {self.opened}")

        max_opened_size = len(self.opened)
        max_closed_size = len(self.closed)

        while len(self.opened):
            f, node = heapq.heappop(self.opened)
            self.closed.add(node)
            self.nodes_expanded += 1

      # Update max sizes for space complexity
            max_opened_size = max(max_opened_size, len(self.opened))
            max_closed_size = max(max_closed_size, len(self.closed))

            logging.info(f"Space complexity - Opened list size: {len(self.opened)}, Closed set size: {len(self.closed)}")
            logging.info(f"Evaluating node: {node} - Opened list size: {len(self.opened)}")


            if node is self.end:
                path = self.get_path()
                path_length = len(path)
                time_taken = time.time() - start_time
                logging.info(f"Found the path with length {path_length-1} in {time_taken:.6f} seconds, with {self.nodes_expanded} nodes expanded.\n")
                logging.info(f"Final space complexity - Opened list size: {len(self.opened)}, Closed set size: {len(self.closed)}")  # Log final sizes
                
                # Log total space complexity
                total_space_complexity = len(self.nodes) + max_opened_size + max_closed_size
                logging.info(f"Total space complexity (nodes + max opened + max closed): {total_space_complexity}")
                return path

            adj_nodes = self.get_adjacent_nodes(node)
            for adj_node in adj_nodes:
                if adj_node.reachable and adj_node not in self.closed:
                    if (adj_node.f, adj_node) in self.opened:
                        if adj_node.g > node.g + self.MOVE_COST:
                            self.update_node(adj_node, node)
                    else:
                        self.update_node(adj_node, node)
                        heapq.heappush(self.opened, (adj_node.f, adj_node))
                        logging.info(f"Added to opened list: {adj_node} - Opened list size after addition: {len(self.opened)}")

        return None
    
    
# Main program execution
def main():
    input_file = 'dungeon_input.txt'
    astar = AStar()
    astar.init_grid(input_file)

    print("\n--The shortest path without eliminating any obstacles--\n")
    logging.info("Attempt to find the shortest path without removing any obstacles.")
    original_path = astar.run()
    if original_path:
        original_path_length = len(original_path)
        formatted_original_path = " -> ".join(f"({x},{y})" for x, y in original_path)
        print(f"1- The shortest path without eliminating any obstacles is {original_path_length - 1}.\nSuch path is {formatted_original_path}\n")
    else:
        print("No solution is found! you need to eliminate more obstacles to find such a walk.")


    print("\n--The shortest path with eliminating obstacles--\n")
    # Attempt to remove specified number of obstacles and find the shortest path
    if astar.num_obstacles_to_remove > 0:
        # print(f"*** Attempt to remove {astar.num_obstacles_to_remove} obstacle(s) from the input file ***")
        logging.info(f"Attempt to remove specified number of obstacles from the input file, user asks to remove {astar.num_obstacles_to_remove} obstacle(s).")
        
        if astar.num_obstacles_to_remove == 1:
            # Remove a single best obstacle
            best_obstacle = astar.find_best_single_obstacle_to_remove()
            if best_obstacle:
                astar.obstacles.remove(best_obstacle)  # Remove the best obstacle
                logging.info(f"Removed obstacle at {best_obstacle}.")

                # Update the reachability of the removed obstacle
                for node in astar.nodes:
                    if (node.x, node.y) == best_obstacle:
                        node.reachable = True  # Make the node reachable again
                        astar.total_obstacles -= 1  # Decrement total obstacles
                        break
            else:
                print("No suitable obstacles to remove.")

        
        elif astar.num_obstacles_to_remove > 1:
            # Remove multiple best obstacles
            best_obstacles = astar.find_best_multiple_obstacles_to_remove()
            if best_obstacles:
                for obstacle in best_obstacles:
                    astar.obstacles.remove(obstacle)  # Remove the best obstacle
                    logging.info(f"Removed obstacle at {obstacle}.")
                    print(f"Removed obstacle(s) at {obstacle}.")

                    # Update the reachability of the removed obstacles
                    for node in astar.nodes:
                        if (node.x, node.y) == obstacle:
                            node.reachable = True  # Make the node reachable again
                            astar.total_obstacles -= 1  # Decrement total obstacles
                            break
            else:
                print("No suitable obstacles to remove.")
        

        # Find the shortest path after removing specified obstacles
        astar.reset_pathfinding()
        logging.info("Attempt to find the shortest path after removing the specified obstacles.")
        new_path = astar.run()

        if new_path:
            new_path_length = len(new_path)
            formatted_new_path = " -> ".join(f"({x},{y})" for x, y in new_path)
            print(f"2- The shortest path after removing obstacle(s) is {new_path_length - 1}.\nSuch path is {formatted_new_path}\n")
        else:
            print("No solution is found after removing obstacles. you need to eliminate more obstacles to find such a walk.")


       # Prompt user to remove more obstacles if any are left
    while True:
        if astar.total_obstacles <= 0:
            print("\nNo more obstacles left to remove.\n")
            break
        
        user_input = input("Do you want to remove more obstacles? (yes/no): ").strip().lower()
        if user_input == 'yes':
            try:
                obstacles_to_remove = int(input(f"How many obstacles do you want to remove (max {astar.total_obstacles})? "))
                if obstacles_to_remove > astar.total_obstacles:
                    print(f"Cannot remove more than {astar.total_obstacles} obstacles.")
                    continue
                
                logging.info("User asks to remove additional obstacles.")
                
                # Implement additional obstacle removal logic here
                if obstacles_to_remove == 1:
                    # For single obstacle removal
                   
                    best_obstacle = astar.find_best_single_obstacle_to_remove()
                    if best_obstacle:
                        astar.obstacles.remove(best_obstacle)
                        

                        # print(f"Removed obstacle at {best_obstacle}.")
                        logging.info(f"Removed obstacle at {best_obstacle}.")
                        
                        # Update reachability
                        for node in astar.nodes:
                            if (node.x, node.y) == best_obstacle:
                                node.reachable = True  # Make the node reachable again
                                astar.total_obstacles -= 1  # Decrement total obstacles
                                break
                        
                        # Reset pathfinding and find the new path
                        astar.reset_pathfinding()
                        new_path = astar.run()
                        if new_path:
                            new_path_length = len(new_path)
                            formatted_new_path = " -> ".join(f"({x},{y})" for x, y in new_path)
                            print(f"\nThe shortest path after removing the obstacle(s) at {best_obstacle} is {new_path_length - 1}.\nSuch path is {formatted_new_path}")
                        else:
                            print("No path found after removing the obstacle.")
                    else:
                        print("No suitable obstacle to remove.")
                else:
                    # For multiple obstacle removal
                    best_obstacles = astar.find_best_multiple_obstacles_to_remove()
                    if best_obstacles:
                        for obstacle in best_obstacles:
                            astar.obstacles.remove(obstacle)
                            print(f"Removed obstacle at {obstacle}.")
                            logging.info(f"Removed obstacle at {obstacle}.")

                            # Update reachability of removed obstacles
                            for node in astar.nodes:
                                if (node.x, node.y) == obstacle:
                                    node.reachable = True  # Make the node reachable again
                                    astar.total_obstacles -= 1  # Decrement total obstacles
                                    break

                        # After removing additional obstacles, reset pathfinding and find the new path
                        astar.reset_pathfinding()
                        new_path = astar.run()
                        if new_path:
                            new_path_length = len(new_path)
                            formatted_new_path = " -> ".join(f"({x},{y})" for x, y in new_path)
                            print(f"New shortest path after removing additional obstacles is {new_path_length - 1}.\nSuch path is {formatted_new_path}")
                        else:
                            print("No path found after removing additional obstacles.")
                    else:
                        print("No suitable obstacles to remove.")
            except ValueError:
                print("Invalid input. Please enter a number.")
        else:
            print("*** Thank you! ***")
            break


if __name__ == "__main__":
    main()
