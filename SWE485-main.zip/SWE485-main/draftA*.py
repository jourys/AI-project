import heapq #for implementing a priority queue
import logging 
import os  #for file system operations (when i created a directory for the logs)
import time  #for performance measurement


# Create a directory for logs 
log_directory = "logs"
if not os.path.exists(log_directory):
    os.makedirs(log_directory)

# Set up logging configuration to log to a file
logging.basicConfig(
    filename=os.path.join(log_directory, 'astar_debug_logs.txt'),
    filemode='w',
    level=logging.INFO,
    format='%(message)s'
)


# Class representing each cell in the grid
class Cell(object):
    def __init__(self, x, y, reachable):
        self.reachable = reachable
        self.x = x
        self.y = y
        self.parent = None
        self.g = float('inf')  # Cost from start to this cell (initialized to infinity)
        self.h = 0 
        self.f = self.g + self.h  # Total cost (g + h)
    # Dunder methods
    def __lt__(self, other):
        """
        Compare cells based on their f values to maintain correct order in the priority queue.
        """
        return self.f < other.f

    def __eq__(self, other):
        """
        Check if two cell objects are equal based on their coordinates.
        This is necessary to avoid processing the same cell multiple times.
        """
        return self.x == other.x and self.y == other.y

    def __hash__(self):
        """
        Return a hash value for the cell, allowing efficient look-up in sets.
        """
        return hash((self.x, self.y))





# A* algorithm implementation
class AStar:
    def __init__(self):
        """
        Initialize the A* algorithm.
        A* algorithm uses two sets to keep track of the nodes:
        - self.closed: tracks nodes that have already been searched to avoid redundant searches.
        - self.opened: a priority queue that determines the next node to explore based on the lowest cost.
        """    
        self.open_set = []  # List of cells to be evaluated
        self.closed_set = set()  # Set of cells already evaluated

        heapq.heapify(self.open_set)  # Transform open_set into a heap
        self.cells = []  # List to store all cells in the grid
        self.num_obstacles_to_remove = 0  # Number of obstacles to remove
        self.obstacles = []  # List to store the positions of obstacles


    def init_grid(self, input_file):
        """
        Initialize the grid from an input file containing dimensions of the dungeon grid (M x N) and obstacle positions.
        :param input_file: Path to the input file
        """
        logging.info(f"Initializing grid from file: {input_file}")
        with open(input_file, 'r') as file:
            # Read grid dimensions
            self.grid_width, self.grid_height = map(int, file.readline().strip().split())
            
            # Read obstacle positions
            for line in file:
                if "Obstacle to remove" in line:
                    self.num_obstacles_to_remove = int(line.split('=')[-1].strip())  # Store number of obstacles to remove
                else:
                    x, y = map(int, line.strip().split())
                    self.obstacles.append((x, y))  # Store obstacles

            # Initialize cells based on grid dimensions and obstacle positions
            for x in range(self.grid_width):
                for y in range(self.grid_height):
                    reachable = (x, y) not in self.obstacles  # Determine if the cell is walkable
                    self.cells.append(Cell(x, y, reachable))  # Initialize cells

            self.start = self.get_cell(0, 0)  # Start cell at (0, 0)
            self.end = self.get_cell(self.grid_width - 1, self.grid_height - 1)  # End cell at bottom-right corner
            self.start.g = 0  # Set starting cell cost to 0
            self.start.h = self.get_heuristic(self.start)  # Calculate heuristic for start cell
            self.start.f = self.start.g + self.start.h  # Total cost (g + h)
            logging.info(f"Grid initialized: {self.grid_width}x{self.grid_height} with obstacles at {self.obstacles}")


    #remove_obstacles method: should be modified because it remove the last obstacle in the set which is randomly
    # def remove_obstacles(self, num_obstacles):
    #     removed_obstacles = []  # Track removed obstacles
    #     for _ in range(min(num_obstacles, len(self.obstacles))):  # Ensure we don't exceed available obstacles
    #         obstacle = self.obstacles.pop()  # Remove the last obstacle
    #         self.get_cell(obstacle[0], obstacle[1]).reachable = True  # Change obstacle to reachable
    #         removed_obstacles.append(obstacle)  # Track removed obstacles
    #     logging.info(f"Removed {len(removed_obstacles)} obstacles, new reachable cells: {removed_obstacles}")
    #     return removed_obstacles  # Return removed obstacles for display



    def get_cell(self, x, y):
        return self.cells[x * self.grid_height + y]  # Calculate index

    def get_adjacent_cells(self, cell):
        cells = []  # List to store adjacent cells
        if cell.x < self.grid_width - 1:  # Right adjacent
            cells.append(self.get_cell(cell.x + 1, cell.y))
        if cell.y > 0:  # Up adjacent
            cells.append(self.get_cell(cell.x, cell.y - 1))
        if cell.x > 0:  # Left adjacent
            cells.append(self.get_cell(cell.x - 1, cell.y))
        if cell.y < self.grid_height - 1:  # Down adjacent
            cells.append(self.get_cell(cell.x, cell.y + 1))
        return cells  # Return the list of adjacent cells



    def find_path(self):
        logging.info(f"im here")

        if not self.end.parent:  # Check if there's no path
            logging.info(f"no path")
            return "No solution"
        path = []  # List to store the path coordinates
        cell = self.end  # Start from the end cell
        while cell.parent is not None:  # Traverse back to the start
            path.append((cell.x, cell.y))  # Add current cell coordinates to the path
            cell = cell.parent  # Move to the parent cell
        path.append((self.start.x, self.start.y))  # Add the start cell
        path.reverse()  # Reverse the path to get the correct order
        total_cost = self.end.g  # Get the total cost from the end cell
        path_string = " -> ".join(f"({x},{y})" for x, y in path)  # Format path string
        logging.info(f"im here1")

        return path_string  # Return the formatted path string



    def update_cell(self, adjacent, cell):
        adjacent.g = cell.g + 1  # Cost from start to the adjacent cell
        adjacent.h = self.get_heuristic(adjacent)  # Heuristic cost to end
        adjacent.parent = cell  # Set parent to current cell
        adjacent.f = adjacent.g + adjacent.h  # Total cost (g + h)
        logging.debug(f"Updated cell ({adjacent.x},{adjacent.y}) -> g: {adjacent.g}, h: {adjacent.h}, f: {adjacent.f}")
                                               
 

    def get_heuristic(self, cell):
        # Manhattan distance heuristic
        return abs(self.end.x - cell.x) + abs(self.end.y - cell.y)  





    def process(self):
        heapq.heappush(self.open_set, self.start)  # Add start cell to the open_set queue
        while self.open_set:  # While there are cells to evaluate
            cell = heapq.heappop(self.open_set)  # Get the cell with the lowest f
            self.closed_set.add(cell)  # Add cell to closed list

            # Log the evaluation of the current cell
            logging.info(f"Evaluating cell ({cell.x},{cell.y}) with:")
            logging.info(f"  g: {cell.g} (Cost to reach this cell)")
            logging.info(f"  h: {cell.h} (Estimated cost to goal)")
            logging.info(f"  f: {cell.f} (Total cost: g + h)")

            if cell == self.end:  # If the end cell is reached
                path_string = self.find_path()
                logging.info(f"Shortest path found with cost {cell.g}: {path_string}")
                print(f"The shortest path is: {path_string}")  # Print the path to the console
                return  # Exit the process


            adj_cells = self.get_adjacent_cells(cell)  # If we didn't reach the goal yet continoue..
            for adj_cell in adj_cells:
                if adj_cell.reachable and adj_cell not in self.closed:  # If cell is reachable and not closed
                    tentative_g = cell.g + 1  # Calculate the tentative g value
                    if tentative_g < adj_cell.g or adj_cell not in self.opened:
                        adj_cell.g = tentative_g  # Update the g value
                        adj_cell.h = self.get_heuristic(adj_cell)  # Update the heuristic
                        adj_cell.f = adj_cell.g + adj_cell.h  # Update the f value
                        adj_cell.parent = cell  # Set parent to current cell
                        if adj_cell not in self.opened:
                            heapq.heappush(self.opened, adj_cell)  # Add to open list
                            logging.debug(f"Added or updated cell ({adj_cell.x},{adj_cell.y}) to open list with g: {adj_cell.g}, h: {adj_cell.h}, f: {adj_cell.f}")



# Instantiate and run the A* algorithm
input_file = 'dungeon_input.txt'
astar = AStar()
astar.init_grid(input_file)  # Initialize the grid from the input file
astar.find_path()  # Call find_path to compute both paths
